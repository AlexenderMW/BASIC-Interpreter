package ICSI311;
//abstract class to derive future nodes
public abstract class Node {

	public Node()
	{
	}
	@Override
	public String toString()
	{
	 return "";
	}
}
